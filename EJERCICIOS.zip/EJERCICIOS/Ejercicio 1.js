function CambiarTitulo() 
{
    newPageTitle = 'El titulo ha cambiado!!!';
    document.title = newPageTitle;
}