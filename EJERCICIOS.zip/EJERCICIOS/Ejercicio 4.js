function consola()
{
    console.log( "Hola mundo" );
    alert ("Hola, ha aparecido un mensaje en consola");
}