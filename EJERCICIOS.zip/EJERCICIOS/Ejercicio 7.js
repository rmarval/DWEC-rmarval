function Ruso()
{
    console.log ("Добро пожаловать"); 
}
function Espaniol()
{   
    console.log ("Bienvenido");
}
function Ingles()
{
   console.log ("Welcome");    
}