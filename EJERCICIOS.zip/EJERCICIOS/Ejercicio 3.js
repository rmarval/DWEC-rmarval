function Falso()
{
  var x = document.getElementById("Falso");
  x.style.fontSize="25px";
  x.style.color="red";
}
function Verdadero()
{
  var x = document.getElementById("Verdadero");
  x.style.fontSize="25px";
  x.style.color="green";
}
function Reset()
{
    var y= document.getElementById("Verdadero");
    var x= document.getElementById("Falso");

    x.style.fontSize="";
    y.style.fontSize="";
    x.style.color="black";
    y.style.color="black";
}

