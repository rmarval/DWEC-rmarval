
function Ruso()
{
    window.alert ("Добро пожаловать"); 
}
function Espaniol()
{  
    window.alert ("Bienvenido");   
}
function Ingles()
{
    window.alert ("Welcome");
}
