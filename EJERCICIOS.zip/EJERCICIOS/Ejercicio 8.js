function Ruso()
{ 
    document.write('<p style="color:blue">Добро пожаловать</p>');
}
function Espaniol()
{
    document.write('<p style="color:red">Bienvenido</p>');
}
function Ingles()
{   
    document.write('<p style="color:green">Welcome</p>');  
}